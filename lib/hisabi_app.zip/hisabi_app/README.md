# حسابي — تطبيق إدارة ديون الزبائن

## هيكلة المشروع

```
lib/
├── main.dart                     # نقطة الدخول + تفعيل Offline Persistence
├── core/
│   ├── theme/                    # الألوان والثيم (مطابق لتصميم الصور)
│   └── constants/                # أسماء الـ collections وثوابت عامة
├── models/                       # StoreModel, CustomerModel, TransactionModel
├── services/
│   ├── firebase_service.dart     # كل استعلامات Firestore (مقيّدة بـ storeId)
│   ├── auth_service.dart         # تسجيل الدخول/الخروج
│   └── connectivity_service.dart # مراقبة حالة الإنترنت (لشريط تنبيه فقط)
├── providers/                    # إدارة الحالة (Provider package)
├── screens/                      # كل شاشة في مجلد مستقل يطابق صورك السبعة
└── routes/                       # كل التنقل بين الشاشات في ملف واحد

firestore.rules                  # قواعد الأمان — عزل بيانات كل بقالة
pubspec.yaml                     # كل المكتبات المطلوبة جاهزة
```

## خطوات التشغيل الأولى

1. ثبّت Flutter SDK إذا ما كان مثبت (flutter.dev).
2. أنشئ مشروع Firebase من console.firebase.google.com.
3. ثبّت أداة FlutterFire: `dart pub global activate flutterfire_cli`
4. من داخل مجلد المشروع نفّذ: `flutterfire configure` (يربط المشروع بـ Firebase ويولّد ملف firebase_options.dart تلقائياً).
5. فعّل السطر الخاص بـ `DefaultFirebaseOptions.currentPlatform` في main.dart بعد الخطوة السابقة.
6. نفّذ `flutter pub get` ثم `flutter run`.
7. ارفع محتوى `firestore.rules` إلى Firebase Console > Firestore > Rules.

## ما هو جاهز الآن
- كل الشاشات السبعة كـ Scaffold فعلي (مو مجرد أفكار) بنفس تسلسل صورك.
- الموديلات الثلاثة (بقالة، زبون، عملية) جاهزة للاستخدام المباشر.
- خدمة Firebase تدعم Offline تلقائياً وتحدّث رصيد الزبون بشكل آمن (Batch + Increment).
- قواعد أمان تمنع أي بقالة من رؤية بيانات بقالة ثانية.

## المتبقي عليك (علامات TODO داخل الملفات)
- ربط كل شاشة بالـ Provider وعرض البيانات الفعلية بدل النصوص المؤقتة.
- بناء نموذج إضافة زبون جديد.
- توليد كشف الحساب كـ PDF (المكتبة موجودة في pubspec: pdf + printing).
- شاشة تسجيل بقالة جديدة (Sign up) كاملة.
