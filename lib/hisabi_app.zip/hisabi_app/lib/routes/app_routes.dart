import 'package:flutter/material.dart';
import '../screens/home/home_screen.dart';
import '../screens/customers/customers_screen.dart';
import '../screens/customer_details/customer_details_screen.dart';
import '../screens/add_transaction/add_transaction_screen.dart';
import '../screens/reports/reports_screen.dart';
import '../screens/settings/settings_screen.dart';
import '../screens/auth/login_screen.dart';
import '../screens/auth/register_store_screen.dart';
import '../screens/auth_wrapper.dart';

class AppRoutes {
  AppRoutes._();

  static const String splash = '/'; // AuthWrapper: يقرر دخول أو رئيسية تلقائياً
  static const String login = '/login';
  static const String registerStore = '/register-store';
  static const String home = '/home';
  static const String customers = '/customers';
  static const String customerDetails = '/customer-details';
  static const String addTransaction = '/add-transaction';
  static const String reports = '/reports';
  static const String settings = '/settings';

  static Route<dynamic> onGenerateRoute(RouteSettings settings) {
    switch (settings.name) {
      case splash:
        return MaterialPageRoute(builder: (_) => const AuthWrapper());
      case login:
        return MaterialPageRoute(builder: (_) => const LoginScreen());
      case registerStore:
        return MaterialPageRoute(builder: (_) => const RegisterStoreScreen());
      case home:
        return MaterialPageRoute(builder: (_) => const HomeScreen());
      case customers:
        return MaterialPageRoute(builder: (_) => const CustomersScreen());
      case customerDetails:
        final customerId = settings.arguments as String;
        return MaterialPageRoute(
          builder: (_) => CustomerDetailsScreen(customerId: customerId),
        );
      case addTransaction:
        final args = settings.arguments as Map<String, String>?;
        return MaterialPageRoute(
          builder: (_) => AddTransactionScreen(
            initialCustomerId: args?['customerId'],
            initialType: args?['type'],
          ),
          fullscreenDialog: true,
        );
      case reports:
        return MaterialPageRoute(builder: (_) => const ReportsScreen());
      case AppRoutes.settings:
        return MaterialPageRoute(builder: (_) => const SettingsScreen());
      default:
        return MaterialPageRoute(
          builder: (_) => const Scaffold(
            body: Center(child: Text('الصفحة غير موجودة')),
          ),
        );
    }
  }
}
