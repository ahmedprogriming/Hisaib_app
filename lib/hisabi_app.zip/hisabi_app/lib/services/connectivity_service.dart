import 'package:connectivity_plus/connectivity_plus.dart';

/// يراقب حالة الشبكة فقط لعرض شريط تنبيه للمستخدم
/// (مثل: "أنت غير متصل، سيتم رفع بياناتك عند توفر الإنترنت").
/// المزامنة الفعلية للبيانات تتم تلقائياً عبر Firestore Offline Persistence،
/// هذه الخدمة لا تدير أي تخزين — فقط واجهة إعلامية.
class ConnectivityService {
  final Connectivity _connectivity = Connectivity();

  Stream<bool> get onConnectivityChanged {
    return _connectivity.onConnectivityChanged.map(
      (results) => !results.contains(ConnectivityResult.none),
    );
  }

  Future<bool> get isConnected async {
    final result = await _connectivity.checkConnectivity();
    return !result.contains(ConnectivityResult.none);
  }
}
