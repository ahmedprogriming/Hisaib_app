import 'package:cloud_firestore/cloud_firestore.dart';
import '../core/constants/app_constants.dart';

/// طبقة الوصول لـ Firestore — كل الاستعلامات هنا "مقيّدة" بـ storeId
/// حتى نضمن عزل بيانات كل بقالة عن الثانية (Multi-tenant isolation).
class FirebaseService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  /// يجب استدعاؤها مرة وحدة عند بداية التطبيق (main.dart)
  static Future<void> enableOfflinePersistence() async {
    FirebaseFirestore.instance.settings = const Settings(
      persistenceEnabled: true,
      cacheSizeBytes: Settings.CACHE_SIZE_UNLIMITED,
    );
  }

  // ---------- مرجع مجموعة زبائن بقالة معينة ----------
  CollectionReference customersRef(String storeId) => _db
      .collection(AppConstants.storesCollection)
      .doc(storeId)
      .collection(AppConstants.customersSubCollection);

  // ---------- مرجع مجموعة عمليات زبون معين ----------
  CollectionReference transactionsRef(String storeId, String customerId) =>
      customersRef(storeId)
          .doc(customerId)
          .collection(AppConstants.transactionsSubCollection);

  /// إضافة عملية جديدة (دين أو دفعة) + تحديث رصيد الزبون تلقائياً
  /// ملاحظة: في الإنتاج يُفضّل نقل تحديث الرصيد إلى Cloud Function
  /// حتى لو صار خطأ لن يفوت التحديث ولن يتكرر الحساب من طرف العميل.
  Future<void> addTransaction({
    required String storeId,
    required String customerId,
    required double amount,
    required String type,
    String? description,
    DateTime? dueDate,
  }) async {
    final batch = _db.batch();

    final txnDoc = transactionsRef(storeId, customerId).doc();
    batch.set(txnDoc, {
      'customerId': customerId,
      'amount': amount,
      'type': type,
      'description': description,
      'date': FieldValue.serverTimestamp(),
      'dueDate': dueDate,
    });

    final customerDoc = customersRef(storeId).doc(customerId);
    final delta = type == AppConstants.transactionTypeDebt ? amount : -amount;
    final updateData = <String, dynamic>{
      'balance': FieldValue.increment(delta),
      'lastTransactionAt': FieldValue.serverTimestamp(),
    };

    // نحدّث تاريخ الاستحقاق فقط عند إضافة دين له تاريخ استحقاق.
    // ملاحظة: هذا تبسيط يخزّن آخر تاريخ استحقاق أُدخل فقط، وليس
    // "الأقرب" من بين عدة ديون مختلفة الاستحقاق — يكفي للنسخة الأولى،
    // ويمكن تطويره لاحقاً بحساب الأقرب فعلياً عبر Cloud Function.
    if (type == AppConstants.transactionTypeDebt && dueDate != null) {
      updateData['nextDueDate'] = dueDate;
    }

    batch.update(customerDoc, updateData);

    await batch.commit();
  }

  /// ينشئ زبون جديد. استخدام customersRef(...).doc() بدون تمرير id
  /// يولّد معرّفاً محلياً فوراً (حتى بدون إنترنت)، فنقدر نرجّعه ونستخدمه
  /// مباشرة (مثلاً لتحديد الزبون تلقائياً في شاشة تسجيل العملية).
  Future<String> addCustomer({
    required String storeId,
    required String name,
    required String phone,
  }) async {
    final doc = customersRef(storeId).doc();
    await doc.set({
      'name': name,
      'phone': phone,
      'balance': 0,
      'lastTransactionAt': FieldValue.serverTimestamp(),
    });
    return doc.id;
  }

  Stream<QuerySnapshot> watchCustomers(String storeId) {
    return customersRef(storeId).orderBy('lastTransactionAt', descending: true).snapshots();
  }

  Stream<QuerySnapshot> watchTransactions(String storeId, String customerId) {
    return transactionsRef(storeId, customerId).orderBy('date', descending: true).snapshots();
  }
}
