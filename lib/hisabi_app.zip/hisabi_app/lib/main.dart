import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:provider/provider.dart';

import 'core/theme/app_theme.dart';
import 'core/constants/app_constants.dart';
import 'services/firebase_service.dart';
import 'services/auth_service.dart';
import 'providers/customers_provider.dart';
import 'routes/app_routes.dart';
// import 'firebase_options.dart'; // يُنشأ تلقائياً عبر: flutterfire configure

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Firebase.initializeApp(
    // options: DefaultFirebaseOptions.currentPlatform,
  );

  // مهم جداً: تفعيل العمل بدون إنترنت قبل أي استخدام لـ Firestore
  await FirebaseService.enableOfflinePersistence();

  runApp(const HisabiApp());
}

class HisabiApp extends StatelessWidget {
  const HisabiApp({super.key});

  @override
  Widget build(BuildContext context) {
    final authService = AuthService();

    return MultiProvider(
      providers: [
        Provider<AuthService>.value(value: authService),

        // يتتبع تسجيل الدخول/الخروج لحظياً في كل التطبيق
        StreamProvider<User?>(
          create: (_) => authService.authStateChanges,
          initialData: authService.currentUser,
        ),

        // يُعاد إنشاؤه تلقائياً فقط عند تغيّر البقالة (تسجيل دخول/خروج)،
        // ويبقى متاحاً فوق كل الشاشات (وليس الرئيسية فقط) حتى تقدر
        // شاشة "تسجيل عملية" مثلاً تصل لقائمة الزبائن مباشرة.
        ChangeNotifierProxyProvider<User?, CustomersProvider>(
          create: (_) => CustomersProvider(storeId: authService.currentStoreId ?? ''),
          update: (_, user, previous) {
            final storeId = user?.uid ?? '';
            if (previous != null && previous.storeId == storeId) return previous;
            return CustomersProvider(storeId: storeId);
          },
        ),
      ],
      child: MaterialApp(
        title: AppConstants.appName,
        debugShowCheckedModeBanner: false,
        theme: AppTheme.light,
        locale: const Locale('ar'),
        supportedLocales: const [Locale('ar'), Locale('en')],
        initialRoute: AppRoutes.splash,
        onGenerateRoute: AppRoutes.onGenerateRoute,
      ),
    );
  }
}
