import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../../core/theme/app_colors.dart';
import '../../providers/customers_provider.dart';
import '../../models/customer_model.dart';
import '../../routes/app_routes.dart';

/// الشاشة الرئيسية — تطابق الصورة الأولى، متصلة فعلياً بالبيانات.
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  String _formatCurrency(double amount) {
    return NumberFormat.decimalPattern('ar').format(amount);
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<CustomersProvider>();
    final debtorsCount = provider.customers.where((c) => c.balance > 0).length;
    // إجمالي المدفوعات الفعلي يتطلب تجميع عمليات "دفعة" عبر كل الزبائن —
    // الأفضل حسابه لاحقاً عبر Cloud Function مجمّعة (aggregation) بدل تحميله
    // على الجهاز مباشرة (راجع سيناريوهات التوسّع اللي ناقشناها سابقاً).
    const totalPaymentsThisPeriod = 0.0;

    final recentCustomers = provider.customers.take(3).toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('حسابي'),
        actions: [
          IconButton(icon: const Icon(Icons.more_vert), onPressed: () {}),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: AppColors.primary,
                borderRadius: BorderRadius.circular(18),
              ),
              child: Column(
                children: [
                  const Text('إجمالي المتبقي عند الزبائن',
                      style: TextStyle(color: Colors.white70, fontSize: 13)),
                  const SizedBox(height: 10),
                  Text(
                    '${_formatCurrency(provider.totalOwed)} ريال',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 30,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: _StatCard(
                    icon: Icons.credit_card,
                    iconColor: AppColors.success,
                    label: 'إجمالي المدفوعات',
                    value: '${_formatCurrency(totalPaymentsThisPeriod)} ريال',
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _StatCard(
                    icon: Icons.people_outline,
                    iconColor: AppColors.primary,
                    label: 'عدد الزبائن المدينين',
                    value: '$debtorsCount',
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            ElevatedButton.icon(
              onPressed: () => Navigator.pushNamed(context, AppRoutes.addTransaction),
              icon: const Icon(Icons.add),
              label: const Text('تسجيل عملية'),
            ),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TextButton(
                  onPressed: () => Navigator.pushNamed(context, AppRoutes.customers),
                  child: const Text('عرض الكل'),
                ),
                const Text('آخر الحسابات',
                    style: TextStyle(fontWeight: FontWeight.w500, fontSize: 16)),
              ],
            ),
            const SizedBox(height: 8),
            if (provider.customers.isEmpty)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 40),
                child: Center(
                  child: Text(
                    'لا يوجد زبائن بعد\nاضغط "تسجيل عملية" لإضافة أول زبون',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: AppColors.textSecondary),
                  ),
                ),
              )
            else
              ...recentCustomers.map((c) => _RecentCustomerTile(customer: c)),
          ],
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: 0,
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.people_outline), label: 'الزبائن'),
          NavigationDestination(icon: Icon(Icons.bar_chart_outlined), label: 'التقارير'),
          NavigationDestination(icon: Icon(Icons.settings_outlined), label: 'الإعدادات'),
        ],
        onDestinationSelected: (i) {
          if (i == 1) Navigator.pushNamed(context, AppRoutes.customers);
          if (i == 2) Navigator.pushNamed(context, AppRoutes.reports);
          if (i == 3) Navigator.pushNamed(context, AppRoutes.settings);
        },
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final IconData icon;
  final Color iconColor;
  final String label;
  final String value;

  const _StatCard({
    required this.icon,
    required this.iconColor,
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: iconColor.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, color: iconColor, size: 18),
          ),
          const SizedBox(height: 10),
          Text(label, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
          const SizedBox(height: 4),
          Text(value, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}

class _RecentCustomerTile extends StatelessWidget {
  final CustomerModel customer;
  const _RecentCustomerTile({required this.customer});

  @override
  Widget build(BuildContext context) {
    final isPaid = customer.balance <= 0;
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(14),
      ),
      child: ListTile(
        onTap: () => Navigator.pushNamed(context, AppRoutes.customerDetails,
            arguments: customer.id),
        leading: CircleAvatar(
          backgroundColor: AppColors.primary.withValues(alpha: 0.12),
          child: Text(
            customer.name.isNotEmpty ? customer.name[0] : '؟',
            style: const TextStyle(color: AppColors.primary, fontWeight: FontWeight.w600),
          ),
        ),
        title: Text(customer.name, style: const TextStyle(fontWeight: FontWeight.w500)),
        trailing: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(isPaid ? 'مسدد' : 'المتبقي عليه',
                style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
            Text(
              '${NumberFormat.decimalPattern('ar').format(customer.balance)} ريال',
              style: TextStyle(
                fontWeight: FontWeight.w600,
                color: isPaid ? AppColors.success : AppColors.danger,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
