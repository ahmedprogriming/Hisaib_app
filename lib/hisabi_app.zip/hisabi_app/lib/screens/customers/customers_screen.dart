import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../../core/constants/app_constants.dart';
import '../../core/theme/app_colors.dart';
import '../../providers/customers_provider.dart';
import '../../models/customer_model.dart';
import '../../routes/app_routes.dart';
import '../../widgets/add_customer_dialog.dart';

/// شاشة الزبائن — تطابق الصورة الثانية:
/// بحث + فلاتر (متأخر / مسدد / عليه دين / الكل) + قائمة الزبائن
class CustomersScreen extends StatefulWidget {
  const CustomersScreen({super.key});

  @override
  State<CustomersScreen> createState() => _CustomersScreenState();
}

class _CustomersScreenState extends State<CustomersScreen> {
  String _selectedFilter = 'all';
  String _searchQuery = '';

  static const _filters = [
    ('متأخر', AppConstants.statusOverdue),
    ('مسدد', AppConstants.statusPaid),
    ('عليه دين', AppConstants.statusOwing),
    ('الكل', 'all'),
  ];

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<CustomersProvider>();

    var customers = provider.filterByStatus(_selectedFilter);
    if (_searchQuery.trim().isNotEmpty) {
      final query = _searchQuery.trim();
      customers = customers
          .where((c) => c.name.contains(query) || c.phone.contains(query))
          .toList();
    }

    return Scaffold(
      appBar: AppBar(title: const Text('الزبائن')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
            child: TextField(
              onChanged: (v) => setState(() => _searchQuery = v),
              decoration: const InputDecoration(
                hintText: 'ابحث عن زبون...',
                prefixIcon: Icon(Icons.search),
              ),
            ),
          ),
          SizedBox(
            height: 40,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              children: _filters.map((f) => _filterChip(f.$1, f.$2)).toList(),
            ),
          ),
          const SizedBox(height: 8),
          Expanded(
            child: customers.isEmpty
                ? Center(
                    child: Text(
                      _searchQuery.isNotEmpty
                          ? 'لا توجد نتائج مطابقة'
                          : 'لا يوجد زبائن في هذا التصنيف',
                      style: const TextStyle(color: AppColors.textSecondary),
                    ),
                  )
                : ListView.builder(
                    padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                    itemCount: customers.length,
                    itemBuilder: (context, i) => _CustomerTile(customer: customers[i]),
                  ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => showAddCustomerDialog(context),
        child: const Icon(Icons.add),
      ),
    );
  }

  Widget _filterChip(String label, String value) {
    final selected = _selectedFilter == value;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4),
      child: ChoiceChip(
        label: Text(label),
        selected: selected,
        onSelected: (_) => setState(() => _selectedFilter = value),
      ),
    );
  }
}

class _CustomerTile extends StatelessWidget {
  final CustomerModel customer;
  const _CustomerTile({required this.customer});

  ({String label, Color bg, Color fg}) _statusStyle() {
    switch (customer.status) {
      case AppConstants.statusOverdue:
        return (label: 'متأخر', bg: AppColors.dangerBg, fg: AppColors.danger);
      case AppConstants.statusOwing:
        return (label: 'عليه دين', bg: AppColors.warningBg, fg: AppColors.warning);
      default:
        return (label: 'مسدد', bg: AppColors.successBg, fg: AppColors.success);
    }
  }

  @override
  Widget build(BuildContext context) {
    final style = _statusStyle();
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(14),
      ),
      child: ListTile(
        onTap: () => Navigator.pushNamed(
          context,
          AppRoutes.customerDetails,
          arguments: customer.id,
        ),
        leading: CircleAvatar(
          backgroundColor: AppColors.primary.withValues(alpha: 0.12),
          child: Text(
            customer.name.isNotEmpty ? customer.name[0] : '؟',
            style: const TextStyle(color: AppColors.primary, fontWeight: FontWeight.w600),
          ),
        ),
        title: Text(customer.name, style: const TextStyle(fontWeight: FontWeight.w500)),
        subtitle: customer.phone.isNotEmpty
            ? Text(customer.phone, textDirection: TextDirection.ltr, textAlign: TextAlign.right)
            : null,
        trailing: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(
                color: style.bg,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(style.label, style: TextStyle(color: style.fg, fontSize: 11)),
            ),
            const SizedBox(height: 4),
            Text(
              '${NumberFormat.decimalPattern('ar').format(customer.balance)} ريال',
              style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13),
            ),
          ],
        ),
      ),
    );
  }
}
