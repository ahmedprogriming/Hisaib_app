import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../services/auth_service.dart';
import '../../routes/app_routes.dart';

/// شاشة الإعدادات — تطابق الصورة الخامسة:
/// بيانات البقالة (الاسم، الهاتف، العملة) + النسخ الاحتياطي
class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  Future<void> _handleLogout(BuildContext context) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('تسجيل الخروج'),
        content: const Text('هل تريد تسجيل الخروج من حسابك؟'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('إلغاء'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('تسجيل الخروج',
                style: TextStyle(color: AppColors.danger)),
          ),
        ],
      ),
    );

    if (confirmed != true) return;

    await AuthService().signOut();

    if (!context.mounted) return;
    Navigator.pushNamedAndRemoveUntil(context, AppRoutes.splash, (r) => false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('الإعدادات')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('بيانات البقالة', style: TextStyle(fontWeight: FontWeight.w500, fontSize: 16)),
          const SizedBox(height: 12),
          TextField(decoration: const InputDecoration(labelText: 'اسم البقالة')),
          const SizedBox(height: 12),
          TextField(decoration: const InputDecoration(labelText: 'رقم الهاتف')),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            decoration: const InputDecoration(labelText: 'العملة'),
            items: const [
              DropdownMenuItem(value: 'YER', child: Text('ريال يمني')),
              DropdownMenuItem(value: 'SAR', child: Text('ريال سعودي')),
            ],
            onChanged: (_) {},
          ),
          const SizedBox(height: 16),
          ElevatedButton(onPressed: () {}, child: const Text('حفظ البيانات')),
          const Divider(height: 40),
          ListTile(
            leading: const Icon(Icons.cloud_upload_outlined),
            title: const Text('النسخ الاحتياطي'),
            subtitle: const Text('احفظ بيانات بقالتك واسترجعها في أي وقت'),
            trailing: const Icon(Icons.chevron_left),
            onTap: () {
              // TODO: تنفيذ تصدير/استيراد نسخة احتياطية
            },
          ),
          const Divider(height: 40),
          ListTile(
            leading: const Icon(Icons.logout, color: AppColors.danger),
            title: const Text('تسجيل الخروج', style: TextStyle(color: AppColors.danger)),
            onTap: () => _handleLogout(context),
          ),
        ],
      ),
    );
  }
}
