import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import 'package:share_plus/share_plus.dart';

import '../../core/constants/app_constants.dart';
import '../../core/theme/app_colors.dart';
import '../../models/customer_model.dart';
import '../../models/transaction_model.dart';
import '../../providers/customers_provider.dart';
import '../../services/firebase_service.dart';
import '../../routes/app_routes.dart';

/// شاشة تفاصيل الزبون — تطابق الصورة الثالثة والرابعة:
/// معلومات الزبون + زر دفعة/دين + سجل المعاملات + إرسال كشف الحساب
class CustomerDetailsScreen extends StatelessWidget {
  final String customerId;
  const CustomerDetailsScreen({super.key, required this.customerId});

  @override
  Widget build(BuildContext context) {
    final customersProvider = context.watch<CustomersProvider>();

    // نبحث عن الزبون داخل القائمة المحمّلة أصلاً بدل طلب مستقل من الشبكة —
    // هذا يخلي الشاشة تفتح فوراً حتى بدون إنترنت.
    final customer = customersProvider.customers
        .cast<CustomerModel?>()
        .firstWhere((c) => c?.id == customerId, orElse: () => null);

    if (customer == null) {
      return const Scaffold(body: Center(child: Text('تعذر العثور على الزبون')));
    }

    return Scaffold(
      appBar: AppBar(title: const Text('تفاصيل الزبون')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _CustomerHeaderCard(customer: customer),
          const SizedBox(height: 16),

          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () => Navigator.pushNamed(
                    context,
                    AppRoutes.addTransaction,
                    arguments: {
                      'customerId': customer.id,
                      'type': AppConstants.transactionTypePayment,
                    },
                  ),
                  icon: const Icon(Icons.payments_outlined),
                  label: const Text('تسجيل دفعة'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: () => Navigator.pushNamed(
                    context,
                    AppRoutes.addTransaction,
                    arguments: {
                      'customerId': customer.id,
                      'type': AppConstants.transactionTypeDebt,
                    },
                  ),
                  icon: const Icon(Icons.add),
                  label: const Text('إضافة دين'),
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),

          const Text('سجل المعاملات', style: TextStyle(fontWeight: FontWeight.w500, fontSize: 15)),
          const SizedBox(height: 10),

          _TransactionsList(storeId: customersProvider.storeId, customerId: customer.id),

          const SizedBox(height: 20),
          OutlinedButton.icon(
            onPressed: () => _shareStatement(context, customer),
            icon: const Icon(Icons.ios_share_outlined),
            label: const Text('إرسال كشف الحساب'),
          ),
        ],
      ),
    );
  }

  Future<void> _shareStatement(BuildContext context, CustomerModel customer) async {
    final storeId = context.read<CustomersProvider>().storeId;
    final firebaseService = FirebaseService();

    // نجلب آخر العمليات مرة واحدة (وليس Stream) فقط لغرض تجميع نص المشاركة
    final snapshot = await firebaseService.transactionsRef(storeId, customer.id)
        .orderBy('date', descending: true)
        .limit(10)
        .get();

    final transactions = snapshot.docs
        .map((d) => TransactionModel.fromMap(d.id, d.data() as Map<String, dynamic>))
        .toList();

    final buffer = StringBuffer()
      ..writeln('كشف حساب — ${customer.name}')
      ..writeln(DateFormat('yyyy/MM/dd', 'ar').format(DateTime.now()))
      ..writeln('—' * 20)
      ..writeln('المتبقي عليه: ${NumberFormat.decimalPattern('ar').format(customer.balance)} ريال')
      ..writeln('—' * 20);

    for (final t in transactions) {
      final sign = t.isDebt ? '+' : '-';
      final label = t.isDebt ? 'مشتريات' : 'دفعة';
      buffer.writeln(
        '${DateFormat('d/M', 'ar').format(t.date)}  •  $label  $sign${NumberFormat.decimalPattern('ar').format(t.amount)} ريال',
      );
    }

    if (!context.mounted) return;
    await SharePlus.instance.share(ShareParams(text: buffer.toString()));
  }
}

class _CustomerHeaderCard extends StatelessWidget {
  final CustomerModel customer;
  const _CustomerHeaderCard({required this.customer});

  @override
  Widget build(BuildContext context) {
    final isPaid = customer.balance <= 0;
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        children: [
          CircleAvatar(
            radius: 28,
            backgroundColor: AppColors.primary.withValues(alpha: 0.12),
            child: Text(
              customer.name.isNotEmpty ? customer.name[0] : '؟',
              style: const TextStyle(color: AppColors.primary, fontSize: 22, fontWeight: FontWeight.w600),
            ),
          ),
          const SizedBox(height: 10),
          Text(customer.name, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600)),
          if (customer.phone.isNotEmpty) ...[
            const SizedBox(height: 2),
            Text(customer.phone,
                textDirection: TextDirection.ltr,
                style: const TextStyle(color: AppColors.textSecondary, fontSize: 13)),
          ],
          const SizedBox(height: 14),
          const Text('المتبقي عليه', style: TextStyle(color: AppColors.textSecondary, fontSize: 12)),
          const SizedBox(height: 4),
          Text(
            '${NumberFormat.decimalPattern('ar').format(customer.balance)} ريال',
            style: TextStyle(
              fontSize: 26,
              fontWeight: FontWeight.w600,
              color: isPaid ? AppColors.success : AppColors.danger,
            ),
          ),
        ],
      ),
    );
  }
}

class _TransactionsList extends StatelessWidget {
  final String storeId;
  final String customerId;
  const _TransactionsList({required this.storeId, required this.customerId});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseService().watchTransactions(storeId, customerId),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting && !snapshot.hasData) {
          return const Padding(
            padding: EdgeInsets.symmetric(vertical: 24),
            child: Center(child: CircularProgressIndicator()),
          );
        }

        final docs = snapshot.data?.docs ?? [];
        if (docs.isEmpty) {
          return const Padding(
            padding: EdgeInsets.symmetric(vertical: 24),
            child: Center(
              child: Text('لا توجد معاملات بعد', style: TextStyle(color: AppColors.textSecondary)),
            ),
          );
        }

        final transactions = docs
            .map((d) => TransactionModel.fromMap(d.id, d.data() as Map<String, dynamic>))
            .toList();

        return Column(
          children: transactions.map((t) => _TransactionTile(transaction: t)).toList(),
        );
      },
    );
  }
}

class _TransactionTile extends StatelessWidget {
  final TransactionModel transaction;
  const _TransactionTile({required this.transaction});

  String _relativeDate(DateTime date) {
    final now = DateTime.now();
    final diff = DateTime(now.year, now.month, now.day)
        .difference(DateTime(date.year, date.month, date.day))
        .inDays;
    if (diff == 0) return 'اليوم';
    if (diff == 1) return 'أمس';
    if (diff == 2) return 'قبل يومين';
    return DateFormat('d/M', 'ar').format(date);
  }

  @override
  Widget build(BuildContext context) {
    final isDebt = transaction.isDebt;
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: (isDebt ? AppColors.dangerBg : AppColors.successBg),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(
              isDebt ? Icons.shopping_cart_outlined : Icons.credit_card,
              size: 16,
              color: isDebt ? AppColors.danger : AppColors.success,
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  transaction.description?.isNotEmpty == true
                      ? transaction.description!
                      : (isDebt ? 'مشتريات' : 'دفعة'),
                  style: const TextStyle(fontWeight: FontWeight.w500, fontSize: 13),
                ),
                Text(_relativeDate(transaction.date),
                    style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
              ],
            ),
          ),
          Text(
            '${isDebt ? '+' : '-'}${NumberFormat.decimalPattern('ar').format(transaction.amount)} ريال',
            style: TextStyle(
              fontWeight: FontWeight.w600,
              color: isDebt ? AppColors.danger : AppColors.success,
            ),
          ),
        ],
      ),
    );
  }
}
