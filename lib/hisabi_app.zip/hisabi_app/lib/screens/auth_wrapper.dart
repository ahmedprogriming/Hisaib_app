import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:provider/provider.dart';
import 'home/home_screen.dart';
import 'auth/login_screen.dart';

/// أول شاشة يفتحها التطبيق فعلياً.
/// تعتمد على StreamProvider<User?> المُعرّف في main.dart (مصدر واحد للحالة)
/// بدل إنشاء اشتراك Stream مستقل هنا.
class AuthWrapper extends StatelessWidget {
  const AuthWrapper({super.key});

  @override
  Widget build(BuildContext context) {
    final user = context.watch<User?>();
    return user != null ? const HomeScreen() : const LoginScreen();
  }
}
