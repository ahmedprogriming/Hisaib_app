import 'package:flutter/material.dart';

/// شاشة التقارير — تطابق الصورة السادسة:
/// فلتر الفترة (اليوم/الأسبوع/الشهر) + كروت الإحصائيات + أعلى الحسابات مديونية
class ReportsScreen extends StatefulWidget {
  const ReportsScreen({super.key});

  @override
  State<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen> {
  String _period = 'month';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('التقارير')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            SegmentedButton<String>(
              segments: const [
                ButtonSegment(value: 'day', label: Text('اليوم')),
                ButtonSegment(value: 'week', label: Text('هذا الأسبوع')),
                ButtonSegment(value: 'month', label: Text('هذا الشهر')),
              ],
              selected: {_period},
              onSelectionChanged: (s) => setState(() => _period = s.first),
            ),
            const SizedBox(height: 16),
            // TODO: شبكة 2x2 من كروت الإحصائيات (يُحسب عبر Cloud Function مجمّعة)
            const Expanded(
              child: Center(child: Text('كروت الإحصائيات + أعلى الحسابات مديونية')),
            ),
          ],
        ),
      ),
    );
  }
}
